const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;
const YOUTUBE_CHANNEL_ID = process.env.YOUTUBE_CHANNEL_ID;

export interface YouTubeVideo {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  publishedAt: string;
  viewCount?: string;
  duration?: string;
  categoryId?: string;
}

export interface YouTubePlaylist {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  itemCount: number;
}

async function youtubeApiFetch(endpoint: string): Promise<unknown> {
  if (!YOUTUBE_API_KEY) {
    console.warn("YOUTUBE_API_KEY not set — using mock data");
    return null;
  }
  const base = "https://www.googleapis.com/youtube/v3";
  const res = await fetch(`${base}${endpoint}&key=${YOUTUBE_API_KEY}`, {
    next: { revalidate: 3600 },
  });
  if (!res.ok) {
    console.error(`YouTube API error: ${res.status} ${res.statusText}`);
    return null;
  }
  return res.json();
}

export async function getChannelVideos(maxResults = 20): Promise<YouTubeVideo[]> {
  const data = await youtubeApiFetch(
    `/search?part=snippet&channelId=${YOUTUBE_CHANNEL_ID}&type=video&order=date&maxResults=${maxResults}`
  ) as { items?: Array<{ id: { videoId: string }; snippet: { title: string; description: string; thumbnails: { high?: { url: string }; default?: { url: string } }; publishedAt: string } }> } | null;

  if (!data?.items) return getMockVideos();

  return data.items.map((item) => ({
    id: item.id.videoId,
    title: item.snippet.title,
    description: item.snippet.description,
    thumbnailUrl:
      item.snippet.thumbnails.high?.url ??
      item.snippet.thumbnails.default?.url ??
      "",
    publishedAt: item.snippet.publishedAt,
  }));
}

export async function getVideoById(videoId: string): Promise<YouTubeVideo | null> {
  const data = await youtubeApiFetch(
    `/videos?part=snippet,statistics,contentDetails&id=${videoId}`
  ) as { items?: Array<{ id: string; snippet: { title: string; description: string; thumbnails: { high?: { url: string } }; publishedAt: string; categoryId: string }; statistics: { viewCount: string }; contentDetails: { duration: string } }> } | null;

  if (!data?.items?.[0]) return null;

  const item = data.items[0];
  return {
    id: item.id,
    title: item.snippet.title,
    description: item.snippet.description,
    thumbnailUrl: item.snippet.thumbnails.high?.url ?? "",
    publishedAt: item.snippet.publishedAt,
    viewCount: item.statistics?.viewCount,
    duration: item.contentDetails?.duration,
    categoryId: item.snippet.categoryId,
  };
}

export function getYouTubeEmbedUrl(videoId: string): string {
  return `https://www.youtube.com/embed/${videoId}?autoplay=0&rel=0&modestbranding=1`;
}

export function getYouTubeThumbnail(videoId: string, quality: "default" | "hq" | "maxres" = "hq"): string {
  const qualityMap = {
    default: "default",
    hq: "hqdefault",
    maxres: "maxresdefault",
  };
  return `https://img.youtube.com/vi/${videoId}/${qualityMap[quality]}.jpg`;
}

function getMockVideos(): YouTubeVideo[] {
  return [
    {
      id: "dQw4w9WgXcQ",
      title: "Construction Site Safety: Essential Protocols",
      description: "Comprehensive overview of construction site safety protocols for new workers.",
      thumbnailUrl: "https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
      publishedAt: "2024-01-15T10:00:00Z",
    },
    {
      id: "5Y7f3V3YpvE",
      title: "PPE Training: Personal Protective Equipment Guide",
      description: "Learn the proper use and maintenance of personal protective equipment.",
      thumbnailUrl: "https://img.youtube.com/vi/5Y7f3V3YpvE/hqdefault.jpg",
      publishedAt: "2024-02-10T10:00:00Z",
    },
    {
      id: "3JZ_D3ELwOQ",
      title: "Emergency Response Procedures",
      description: "What to do in case of workplace emergencies — step-by-step guide.",
      thumbnailUrl: "https://img.youtube.com/vi/3JZ_D3ELwOQ/hqdefault.jpg",
      publishedAt: "2024-03-05T10:00:00Z",
    },
    {
      id: "9bZkp7q19f0",
      title: "Hazardous Materials Handling",
      description: "Proper techniques for handling and storing hazardous materials safely.",
      thumbnailUrl: "https://img.youtube.com/vi/9bZkp7q19f0/hqdefault.jpg",
      publishedAt: "2024-04-01T10:00:00Z",
    },
    {
      id: "OPf0YbXqDm0",
      title: "Fire Safety & Evacuation Procedures",
      description: "Fire prevention, detection and evacuation plans for industrial facilities.",
      thumbnailUrl: "https://img.youtube.com/vi/OPf0YbXqDm0/hqdefault.jpg",
      publishedAt: "2024-04-20T10:00:00Z",
    },
    {
      id: "hT_nvWreIhg",
      title: "Working at Heights: Safety Training",
      description: "Essential training for workers who operate at height — fall prevention and harness use.",
      thumbnailUrl: "https://img.youtube.com/vi/hT_nvWreIhg/hqdefault.jpg",
      publishedAt: "2024-05-10T10:00:00Z",
    },
  ];
}
