const WP_API_URL = process.env.WORDPRESS_API_URL ?? "https://blog.peoplepulsemedia.com/wp-json/wp/v2";
const WP_API_TOKEN = process.env.WORDPRESS_API_TOKEN;

function getHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (WP_API_TOKEN) {
    headers["Authorization"] = `Bearer ${WP_API_TOKEN}`;
  }
  return headers;
}

export interface WPPost {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  modified: string;
  featuredImage?: string;
  author: string;
  categories: string[];
  tags: string[];
}

export interface WPFaq {
  id: number;
  question: string;
  answer: string;
  category?: string;
}

async function wpFetch(path: string): Promise<unknown> {
  try {
    const res = await fetch(`${WP_API_URL}${path}`, {
      headers: getHeaders(),
      next: { revalidate: 3600 },
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export async function getWPPosts(page = 1, perPage = 9): Promise<{ posts: WPPost[]; total: number; totalPages: number }> {
  interface WPPostRaw {
    id: number;
    slug: string;
    title: { rendered: string };
    excerpt: { rendered: string };
    content: { rendered: string };
    date: string;
    modified: string;
  }
  const data = await wpFetch(`/posts?_embed&page=${page}&per_page=${perPage}`) as WPPostRaw[] | null;
  if (!data) return { posts: getMockPosts(), total: 9, totalPages: 1 };

  const posts: WPPost[] = data.map((p) => ({
    id: p.id,
    slug: p.slug,
    title: p.title.rendered,
    excerpt: p.excerpt.rendered,
    content: p.content.rendered,
    date: p.date,
    modified: p.modified,
    author: "People Pulse Media Team",
    categories: [],
    tags: [],
  }));

  return { posts, total: posts.length, totalPages: 1 };
}

export async function getWPPostBySlug(slug: string): Promise<WPPost | null> {
  interface WPPostRaw {
    id: number;
    slug: string;
    title: { rendered: string };
    excerpt: { rendered: string };
    content: { rendered: string };
    date: string;
    modified: string;
  }
  const data = await wpFetch(`/posts?slug=${slug}&_embed`) as WPPostRaw[] | null;
  if (!data?.[0]) return getMockPosts().find((p) => p.slug === slug) ?? null;

  const p = data[0];
  return {
    id: p.id,
    slug: p.slug,
    title: p.title.rendered,
    excerpt: p.excerpt.rendered,
    content: p.content.rendered,
    date: p.date,
    modified: p.modified,
    author: "People Pulse Media Team",
    categories: [],
    tags: [],
  };
}

export async function getWPFaqs(): Promise<WPFaq[]> {
  interface WPFaqRaw {
    id: number;
    title: { rendered: string };
    content: { rendered: string };
    faq_category?: string[];
  }
  const data = await wpFetch("/faqs?per_page=20") as WPFaqRaw[] | null;
  if (!data) return getMockFaqs();

  return data.map((f) => ({
    id: f.id,
    question: f.title.rendered,
    answer: f.content.rendered.replace(/<[^>]*>/g, ""),
    category: f.faq_category?.[0] ?? "General",
  }));
}

function getMockPosts(): WPPost[] {
  return [
    {
      id: 1,
      slug: "why-safety-videos-matter-for-onboarding",
      title: "Why Safety Videos Are Critical for Modern Workplace Onboarding",
      excerpt: "Discover how high-quality safety videos dramatically improve compliance rates and reduce workplace incidents during employee onboarding.",
      content: "<p>In today's fast-paced work environments, ensuring every employee understands safety protocols is more critical than ever...</p>",
      date: "2024-08-15T10:00:00",
      modified: "2024-08-20T12:00:00",
      featuredImage: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800",
      author: "Sarah Mitchell",
      categories: ["Safety", "Onboarding"],
      tags: ["workplace safety", "training", "compliance"],
    },
    {
      id: 2,
      slug: "multilingual-onboarding-global-workforce",
      title: "Multilingual Onboarding: Reaching Every Worker in Their Language",
      excerpt: "How PULSYON's multilingual capabilities transform onboarding for global workforces and improve comprehension by up to 70%.",
      content: "<p>Language barriers in workplace training lead to misunderstandings, non-compliance, and increased risk...</p>",
      date: "2024-07-22T10:00:00",
      modified: "2024-07-25T12:00:00",
      featuredImage: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=800",
      author: "James Okonkwo",
      categories: ["Onboarding", "Technology"],
      tags: ["multilingual", "PULSYON", "global workforce"],
    },
    {
      id: 3,
      slug: "digital-content-strategy-construction-industry",
      title: "Digital Content Strategy for the Construction Industry",
      excerpt: "Building a comprehensive digital content strategy that engages workers, builds safety culture, and drives measurable results.",
      content: "<p>The construction industry faces unique communication challenges — dispersed worksites, diverse workforces, and high-stakes safety requirements...</p>",
      date: "2024-06-10T10:00:00",
      modified: "2024-06-15T12:00:00",
      featuredImage: "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=800",
      author: "People Pulse Media Team",
      categories: ["Content Strategy", "Construction"],
      tags: ["digital content", "construction", "strategy"],
    },
    {
      id: 4,
      slug: "measuring-roi-safety-training-programs",
      title: "Measuring the ROI of Your Safety Training Programs",
      excerpt: "A practical framework for quantifying the return on investment of workplace safety training initiatives.",
      content: "<p>Safety training is often seen as a cost center — but when done right, it's one of the highest-ROI investments a company can make...</p>",
      date: "2024-05-28T10:00:00",
      modified: "2024-05-30T12:00:00",
      featuredImage: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800",
      author: "Sarah Mitchell",
      categories: ["Safety", "Business"],
      tags: ["ROI", "safety training", "measurement"],
    },
    {
      id: 5,
      slug: "video-production-industrial-environments",
      title: "Video Production in Industrial Environments: Our Approach",
      excerpt: "Behind the scenes of producing high-quality safety and training videos in demanding industrial settings.",
      content: "<p>Filming in an active refinery, a construction site, or a manufacturing facility requires meticulous planning...</p>",
      date: "2024-04-12T10:00:00",
      modified: "2024-04-15T12:00:00",
      featuredImage: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=800",
      author: "James Okonkwo",
      categories: ["Production", "Behind the Scenes"],
      tags: ["video production", "industrial", "behind the scenes"],
    },
    {
      id: 6,
      slug: "pulsyon-assessment-features-deep-dive",
      title: "PULSYON Assessment Features: A Deep Dive",
      excerpt: "Explore PULSYON's comprehensive assessment capabilities — from AI-powered question generation to detailed analytics dashboards.",
      content: "<p>PULSYON's assessment module goes far beyond simple quizzes. It's a full-featured evaluation platform...</p>",
      date: "2024-03-20T10:00:00",
      modified: "2024-03-22T12:00:00",
      featuredImage: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800",
      author: "People Pulse Media Team",
      categories: ["Technology", "PULSYON"],
      tags: ["PULSYON", "assessment", "features"],
    },
  ];
}

function getMockFaqs(): WPFaq[] {
  return [
    {
      id: 1,
      question: "What types of safety videos does People Pulse Media produce?",
      answer: "We produce a full range of safety videos including induction training, PPE guidance, emergency response, hazardous materials handling, working at heights, fire safety, and site-specific safety procedures. All videos are professionally produced and can be tailored to your brand and industry.",
      category: "Safety Videos",
    },
    {
      id: 2,
      question: "What is PULSYON and how does it work?",
      answer: "PULSYON is our multilingual onboarding and assessment platform designed for enterprise workforces. It delivers training content in workers' native languages, tracks completion and comprehension through built-in assessments, and provides managers with real-time analytics dashboards. It integrates with your existing HR systems and supports unlimited users.",
      category: "PULSYON",
    },
    {
      id: 3,
      question: "How long does it take to produce a safety video?",
      answer: "Production timelines vary based on complexity and length. Typically, a standard safety training video (5–10 minutes) takes 4–6 weeks from brief to delivery, including scripting, filming, editing, and review rounds. Rush production options are available for urgent requirements.",
      category: "Safety Videos",
    },
    {
      id: 4,
      question: "How many languages does PULSYON support?",
      answer: "PULSYON currently supports over 40 languages, covering the major languages spoken by industrial workforces globally. This includes Arabic, Tagalog, Hindi, Urdu, Bengali, Indonesian, Vietnamese, Spanish, Portuguese, French, and many more. New languages can be added on request.",
      category: "PULSYON",
    },
    {
      id: 5,
      question: "Can you produce videos in multiple languages?",
      answer: "Absolutely. We specialise in multilingual video production. We can produce voice-overs, subtitles, and fully localised versions of any video in 40+ languages. This is particularly important for industries with diverse, international workforces.",
      category: "Safety Videos",
    },
    {
      id: 6,
      question: "What industries do you work with?",
      answer: "We work across a wide range of industries including oil & gas, construction, manufacturing, logistics, hospitality, healthcare, retail, and more. Our team has deep experience producing content that meets the specific regulatory and cultural requirements of each sector.",
      category: "General",
    },
    {
      id: 7,
      question: "Does PULSYON integrate with our existing HRIS/LMS?",
      answer: "Yes. PULSYON is designed for seamless enterprise integration. It supports SCORM, xAPI, and direct API integrations with major HR and LMS platforms including SAP SuccessFactors, Workday, Oracle HCM, Cornerstone OnDemand, and more. Our implementation team handles the full technical integration.",
      category: "PULSYON",
    },
    {
      id: 8,
      question: "How is PULSYON priced?",
      answer: "PULSYON is priced on a per-user, per-year subscription model with volume discounts for large workforces. Pricing depends on the number of users, languages required, and level of customisation. Contact us for a tailored proposal or book a demo to see the platform in action.",
      category: "PULSYON",
    },
  ];
}
