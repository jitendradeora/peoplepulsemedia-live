import SectionHeading from "@/components/ui/SectionHeading";

const steps = [
  {
    number: "01",
    title: "Discovery & Brief",
    description:
      "We begin with a deep-dive into your workforce, industry, regulatory requirements, and existing content. Every project starts with understanding your unique context.",
  },
  {
    number: "02",
    title: "Script & Storyboard",
    description:
      "Our content specialists write scripts that are clear, accurate, and engaging. Storyboards map every scene, ensuring alignment before a single frame is filmed.",
  },
  {
    number: "03",
    title: "Production",
    description:
      "Our film crew brings the vision to life — on-site, in studios, or with animation. We work in live industrial environments with full safety compliance.",
  },
  {
    number: "04",
    title: "Post-Production & Localisation",
    description:
      "Professional editing, colour grading, and sound design. Content is then localised into your required languages by certified translators and voice artists.",
  },
  {
    number: "05",
    title: "Review & Delivery",
    description:
      "Multiple review rounds to ensure every detail is right. Final delivery in your required formats — ready for PULSYON, your LMS, or broadcast.",
  },
];

export default function ProcessSteps() {
  return (
    <section className="py-24 lg:py-32 bg-[#FAFAF8]" aria-labelledby="process-heading">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="How We Work"
          title="Our Proven Production Process"
          description="From first brief to final delivery — a structured, transparent process that delivers exceptional results every time."
          align="left"
          className="mb-16"
        />

        <div className="relative">
          {/* Connecting line on desktop */}
          <div className="hidden lg:block absolute left-[2.25rem] top-10 bottom-10 w-px bg-gradient-to-b from-[#E8521A] to-transparent" aria-hidden="true" />

          <div className="space-y-8">
            {steps.map((step) => (
              <div key={step.number} className="flex gap-6 lg:gap-10 group">
                <div className="flex flex-col items-center gap-2 shrink-0">
                  <div className="w-[4.5rem] h-[4.5rem] rounded-2xl bg-white border-2 border-[#E8521A]/20 group-hover:border-[#E8521A] group-hover:bg-[#E8521A] flex items-center justify-center transition-all duration-300 shadow-sm relative z-10">
                    <span className="text-lg font-bold text-[#E8521A] group-hover:text-white transition-colors">
                      {step.number}
                    </span>
                  </div>
                </div>
                <div className="flex-1 pb-8">
                  <h3 className="text-xl font-bold text-[#0A0A0A] mb-2 group-hover:text-[#E8521A] transition-colors">
                    {step.title}
                  </h3>
                  <p className="text-gray-500 leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
