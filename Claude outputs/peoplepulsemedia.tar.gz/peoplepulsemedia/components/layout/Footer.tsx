import Link from "next/link";
import Image from "next/image";
import { Mail, Phone, MapPin } from "lucide-react";
import { LinkedinIcon, YoutubeIcon } from "@/components/ui/SocialIcons";

const footerLinks = {
  Services: [
    { href: "/safety-videos", label: "Safety Videos" },
    { href: "/onboarding-assessment", label: "PULSYON Platform" },
    { href: "/our-work", label: "Our Work" },
  ],
  Company: [
    { href: "/blog", label: "Blog" },
    { href: "/contact", label: "Contact" },
    { href: "/contact#book", label: "Book a Meeting" },
  ],
  Legal: [
    { href: "/privacy", label: "Privacy Policy" },
    { href: "/terms", label: "Terms of Service" },
  ],
};

const socials = [
  { href: "https://www.linkedin.com/company/peoplepulsemedia", label: "LinkedIn", Icon: LinkedinIcon },
  { href: "https://www.youtube.com/@peoplepulsemedia", label: "YouTube", Icon: YoutubeIcon },
];

export default function Footer() {
  return (
    <footer className="bg-[#0A0A0A] text-white" role="contentinfo">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top section */}
        <div className="py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2 space-y-5">
            <Link href="/" className="flex items-center gap-3" aria-label="People Pulse Media — Home">
              <div className="relative w-12 h-12">
                <Image
                  src="/people-pulse-media-logo.png"
                  alt="People Pulse Media"
                  fill
                  className="object-contain"
                />
              </div>
              <div>
                <div className="font-bold text-lg text-white leading-tight">People Pulse Media</div>
                <div className="text-[#E8521A] text-sm font-medium">Powered by PULSYON</div>
              </div>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
              Premium safety video production and multilingual onboarding solutions for enterprise workforces worldwide.
            </p>
            <div className="space-y-2">
              <a href="mailto:hello@peoplepulsemedia.com" className="flex items-center gap-2 text-gray-400 hover:text-white text-sm transition-colors">
                <Mail className="w-4 h-4 text-[#E8521A]" />
                hello@peoplepulsemedia.com
              </a>
              <a href="tel:+971501234567" className="flex items-center gap-2 text-gray-400 hover:text-white text-sm transition-colors">
                <Phone className="w-4 h-4 text-[#E8521A]" />
                +971 50 123 4567
              </a>
              <div className="flex items-start gap-2 text-gray-400 text-sm">
                <MapPin className="w-4 h-4 text-[#E8521A] mt-0.5 shrink-0" />
                Dubai, United Arab Emirates
              </div>
            </div>
            <div className="flex items-center gap-3">
              {socials.map(({ href, label, Icon }) => (
                <a
                  key={href}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#E8521A] transition-colors"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-white font-semibold text-sm mb-5 uppercase tracking-wider">{category}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-gray-400 hover:text-white text-sm transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* CTA bar */}
        <div className="py-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-400 text-sm">Ready to transform your workforce training?</p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Link
              href="/contact#book"
              className="inline-flex items-center justify-center bg-[#E8521A] text-white font-semibold text-sm px-6 py-2.5 rounded-full hover:bg-[#C43F0E] transition-colors"
            >
              Book a Meeting
            </Link>
            <Link
              href="/onboarding-assessment#demo"
              className="inline-flex items-center justify-center border border-white/20 text-white font-semibold text-sm px-6 py-2.5 rounded-full hover:border-[#E8521A] hover:text-[#E8521A] transition-colors"
            >
              Book a PULSYON Demo
            </Link>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="py-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-gray-500 text-xs">
            © {new Date().getFullYear()} People Pulse Media. All rights reserved.
          </p>
          <p className="text-gray-600 text-xs">
            Built with precision. Powered by PULSYON.
          </p>
        </div>
      </div>
    </footer>
  );
}
