import type { Metadata } from "next";
import { Suspense } from "react";
import HeroBanner from "@/components/hero/HeroBanner";
import SectionHeading from "@/components/ui/SectionHeading";
import CTABanner from "@/components/ui/CTABanner";
import ProcessSteps from "@/components/sections/ProcessSteps";
import VideoCard from "@/components/cards/VideoCard";
import JsonLd from "@/components/seo/JsonLd";
import { webPageSchema, serviceSchema, videoObjectSchema } from "@/lib/schema";
import { getChannelVideos } from "@/lib/youtube";
import { absoluteUrl } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Safety Training Videos",
  description:
    "Watch our premium HSE and workplace safety training videos — covering construction, oil & gas, PPE, fire safety, working at heights, and more. Available in 40+ languages.",
  alternates: { canonical: "/safety-videos" },
  openGraph: {
    title: "Safety Training Videos | People Pulse Media",
    description: "Cinematic safety training videos for enterprise workforces in 40+ languages.",
    url: "/safety-videos",
  },
};

const safetyCategories = [
  "All",
  "Construction",
  "Oil & Gas",
  "Fire Safety",
  "PPE",
  "Working at Heights",
  "Emergency Response",
];

const productionFeatures = [
  {
    title: "On-Site Filming",
    desc: "We film in live industrial environments — refineries, construction sites, manufacturing plants — capturing the real context of your safety requirements.",
  },
  {
    title: "40+ Languages",
    desc: "Every video can be produced with professional voice-overs, subtitles, and on-screen text in the languages your workforce speaks.",
  },
  {
    title: "Regulatory Compliance",
    desc: "Content aligned with OSHA, ISO 45001, and regional regulatory frameworks, reviewed by certified HSE professionals.",
  },
  {
    title: "Cinematic Quality",
    desc: "4K production with professional lighting, colour grading, and sound design — training content that workers actually want to watch.",
  },
];

export default async function SafetyVideosPage() {
  const videos = await getChannelVideos(12);

  const schemas = [
    webPageSchema({
      name: "Safety Training Videos",
      description: "Premium workplace safety training videos in 40+ languages.",
      url: absoluteUrl("/safety-videos"),
      breadcrumbs: [
        { name: "Home", url: absoluteUrl("/") },
        { name: "Safety Videos", url: absoluteUrl("/safety-videos") },
      ],
    }),
    serviceSchema({
      name: "Safety Video Production",
      description: "Professional safety training video production for enterprise workforces.",
      url: absoluteUrl("/safety-videos"),
    }),
    ...videos.slice(0, 5).map((v) =>
      videoObjectSchema({
        name: v.title,
        description: v.description,
        thumbnailUrl: v.thumbnailUrl,
        uploadDate: v.publishedAt,
        embedUrl: `https://www.youtube.com/embed/${v.id}`,
      })
    ),
  ];

  return (
    <>
      <JsonLd data={schemas} />

      <HeroBanner
        eyebrow="Safety Video Library"
        title="Safety Training Videos That Workers Remember"
        description="Cinematic, scenario-based safety content produced for enterprise workforces — available in 40+ languages."
        cta={{ label: "Book a Production Meeting", href: "/contact?service=safety-videos#book" }}
        breadcrumbs={[{ label: "Safety Videos" }]}
      />

      {/* Production features */}
      <section className="py-20 bg-white" aria-labelledby="production-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="Our Approach"
            title="What Makes Our Safety Videos Different"
            description="We don't make talking-head training videos. We make content that genuinely changes behaviour."
            className="mb-14"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {productionFeatures.map((f) => (
              <div key={f.title} className="bg-[#FAFAF8] rounded-2xl p-6 border border-gray-100">
                <div className="w-2 h-8 bg-[#E8521A] rounded-full mb-5" aria-hidden="true" />
                <h3 className="font-bold text-[#0A0A0A] mb-2">{f.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Video library */}
      <section className="py-20 bg-[#FAFAF8]" aria-labelledby="video-library-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="Video Library"
            title="Browse Our Safety Videos"
            description="A selection from our library of workplace safety training content."
            className="mb-10"
          />

          {/* Categories */}
          <div className="flex flex-wrap gap-2 mb-10" role="group" aria-label="Video categories">
            {safetyCategories.map((cat) => (
              <button
                key={cat}
                className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
                  cat === "All"
                    ? "bg-[#E8521A] text-white border-[#E8521A]"
                    : "bg-white text-gray-600 border-gray-200 hover:border-[#E8521A] hover:text-[#E8521A]"
                }`}
                aria-pressed={cat === "All"}
              >
                {cat}
              </button>
            ))}
          </div>

          <Suspense fallback={
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="rounded-2xl bg-gray-100 aspect-video animate-pulse" />
              ))}
            </div>
          }>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {videos.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          </Suspense>
        </div>
      </section>

      {/* Production Process */}
      <ProcessSteps />

      <CTABanner
        eyebrow="Commission a Video"
        title="Need a Custom Safety Video?"
        description="Tell us your requirements and we'll produce a cinematic, multilingual safety video tailored to your industry, workforce, and brand."
        primaryCta={{ label: "Book a Production Meeting", href: "/contact?service=safety-videos#book" }}
        secondaryCta={{ label: "View Our Work", href: "/our-work" }}
      />
    </>
  );
}
