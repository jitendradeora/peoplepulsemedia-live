import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Globe, Award, Users, Clock } from "lucide-react";
import HeroVideo from "@/components/hero/HeroVideo";
import ServicesSection from "@/components/sections/ServicesSection";
import ProblemSolutionSection from "@/components/sections/ProblemSolutionSection";
import ProcessSteps from "@/components/sections/ProcessSteps";
import Testimonials from "@/components/sections/Testimonials";
import CTABanner from "@/components/ui/CTABanner";
import SectionHeading from "@/components/ui/SectionHeading";
import FAQAccordion from "@/components/faq/FAQAccordion";
import NewsletterForm from "@/components/forms/NewsletterForm";
import JsonLd from "@/components/seo/JsonLd";
import { webPageSchema, faqSchema } from "@/lib/schema";
import { getWPFaqs } from "@/lib/wordpress";
import { absoluteUrl } from "@/lib/utils";

export const metadata: Metadata = {
  title: "People Pulse Media — Safety Videos & PULSYON Onboarding Platform",
  description:
    "We produce premium safety training videos and power workforce onboarding with PULSYON — our multilingual assessment platform trusted by enterprises across the region.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "People Pulse Media — Safety Videos & PULSYON",
    description:
      "Premium safety video production and PULSYON — the multilingual onboarding & assessment platform for enterprise workforces.",
    url: "/",
  },
};

const stats = [
  { value: "40+", label: "Languages" },
  { value: "200+", label: "Videos Produced" },
  { value: "50K+", label: "Workers Trained" },
  { value: "98%", label: "Client Retention" },
];

export default async function HomePage() {
  const faqs = await getWPFaqs();

  const pageSchema = webPageSchema({
    name: "People Pulse Media — Safety Videos & PULSYON",
    description: "Premium safety video production and multilingual onboarding platform.",
    url: absoluteUrl("/"),
  });

  const faqStructuredData = faqSchema(faqs.map((f) => ({ question: f.question, answer: f.answer })));

  return (
    <>
      <JsonLd data={[pageSchema, faqStructuredData]} />

      {/* Hero */}
      <HeroVideo
        subtitle="People Pulse Media"
        title="Training Content That Moves People to Action"
        description="We produce cinematic safety videos and power workforce onboarding with PULSYON — our multilingual platform built for enterprise teams."
        primaryCta={{ label: "Book a Meeting", href: "/contact#book" }}
        secondaryCta={{ label: "Watch Safety Videos", href: "/safety-videos" }}
        stats={stats}
      />

      {/* About */}
      <section className="py-24 lg:py-32 bg-white" aria-labelledby="about-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 mb-5">
                <div className="w-6 h-0.5 bg-[#E8521A]" aria-hidden="true" />
                <span className="text-[#E8521A] text-xs font-bold uppercase tracking-[0.2em]">About Us</span>
              </div>
              <h2 id="about-heading" className="text-4xl lg:text-5xl font-bold text-[#0A0A0A] leading-tight mb-6">
                We Make Safety Training <span className="text-[#E8521A]">Impossible to Ignore</span>
              </h2>
              <p className="text-gray-500 text-lg leading-relaxed mb-6">
                People Pulse Media is a premium content production house and technology company
                specialising in safety training and workforce onboarding. Our two core offerings —
                cinematic safety videos and the PULSYON platform — are trusted by enterprise clients
                across the oil & gas, construction, manufacturing, and logistics sectors.
              </p>
              <p className="text-gray-500 leading-relaxed mb-8">
                Based in Dubai, we work across the Middle East, Asia, and beyond. Every project
                starts with one goal: ensuring workers don&rsquo;t just watch training — they understand it,
                retain it, and apply it.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 text-[#E8521A] font-bold hover:text-[#C43F0E] group"
              >
                Talk to our team
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { Icon: Globe, title: "40+ Languages", desc: "Reach every worker in their native language" },
                { Icon: Award, title: "Premium Quality", desc: "Cinematic production that sets the industry standard" },
                { Icon: Users, title: "Enterprise Ready", desc: "Scalable from 100 to 100,000+ workers" },
                { Icon: Clock, title: "Fast Turnaround", desc: "4-6 week average production timeline" },
              ].map(({ Icon, title, desc }) => (
                <div key={title} className="bg-[#FAFAF8] rounded-2xl p-6 border border-gray-100">
                  <div className="w-10 h-10 rounded-xl bg-[#E8521A]/10 flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5 text-[#E8521A]" aria-hidden="true" />
                  </div>
                  <h3 className="font-bold text-[#0A0A0A] mb-1">{title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <ServicesSection />

      {/* Problems & Solutions */}
      <ProblemSolutionSection />

      {/* Process */}
      <ProcessSteps />

      {/* Testimonials */}
      <Testimonials />

      {/* FAQ */}
      <section className="py-24 lg:py-32 bg-white" aria-labelledby="faq-heading">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="FAQ"
            title="Frequently Asked Questions"
            description="Everything you need to know about our services and the PULSYON platform."
            className="mb-12"
          />
          <FAQAccordion faqs={faqs} />
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-[#FAFAF8] border-t border-gray-100" aria-labelledby="newsletter-heading">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 id="newsletter-heading" className="text-2xl font-bold text-[#0A0A0A] mb-3">
            Get Insights on Safety & Workforce Training
          </h2>
          <p className="text-gray-500 mb-8">
            Join 2,000+ HSE and HR professionals who receive our monthly newsletter.
          </p>
          <NewsletterForm />
        </div>
      </section>

      {/* CTA */}
      <CTABanner
        eyebrow="Get Started"
        title="Ready to Transform Your Workforce Training?"
        description="Book a meeting to discuss your safety video needs, or see PULSYON in action with a personalised demo."
        primaryCta={{ label: "Book a Meeting", href: "/contact#book" }}
        secondaryCta={{ label: "Book a PULSYON Demo", href: "/onboarding-assessment#demo" }}
      />
    </>
  );
}
