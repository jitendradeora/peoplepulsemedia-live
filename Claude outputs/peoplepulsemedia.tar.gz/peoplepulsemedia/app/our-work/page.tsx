import type { Metadata } from "next";
import HeroBanner from "@/components/hero/HeroBanner";
import SectionHeading from "@/components/ui/SectionHeading";
import CTABanner from "@/components/ui/CTABanner";
import CaseStudyCard, { type CaseStudy } from "@/components/cards/CaseStudyCard";
import JsonLd from "@/components/seo/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { absoluteUrl } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Our Work — Case Studies & Projects",
  description:
    "Explore People Pulse Media's portfolio of safety video productions, onboarding solutions, and digital content projects across oil & gas, construction, manufacturing, and more.",
  alternates: { canonical: "/our-work" },
  openGraph: {
    title: "Our Work | People Pulse Media",
    description: "Case studies and projects from People Pulse Media — safety video production and PULSYON onboarding.",
    url: "/our-work",
  },
};

export const caseStudies: CaseStudy[] = [
  {
    slug: "gulf-energy-group-safety-onboarding",
    title: "Multilingual Safety Onboarding for 8,000 Workers",
    client: "Gulf Energy Group",
    industry: "Oil & Gas",
    description: "We deployed PULSYON across 5 sites, delivering induction training in Arabic, Tagalog, Hindi, and Urdu — reducing non-compliance incidents by 62%.",
    imageSrc: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800",
    tags: ["PULSYON", "Multilingual", "Safety"],
    results: "62% reduction in non-compliance incidents",
  },
  {
    slug: "nexus-construction-hse-video-series",
    title: "30-Part HSE Video Series for Major Construction Group",
    client: "Nexus Construction",
    industry: "Construction",
    description: "A comprehensive 30-video safety training series filmed across 4 active construction sites — covering everything from PPE to emergency response.",
    imageSrc: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800",
    tags: ["Safety Videos", "Construction", "HSE"],
    results: "30 videos delivered in 6 languages",
  },
  {
    slug: "atlas-manufacturing-digital-induction",
    title: "Digital Induction Platform Rollout Across 12 Sites",
    client: "Atlas Manufacturing",
    industry: "Manufacturing",
    description: "PULSYON replaced a paper-based induction system across 12 global manufacturing sites, reducing induction time by 40% while improving comprehension scores.",
    imageSrc: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=800",
    tags: ["PULSYON", "Digital Transformation"],
    results: "40% faster induction, 94% pass rate",
  },
  {
    slug: "meridian-logistics-driver-safety-training",
    title: "Driver Safety Training Video Programme",
    client: "Meridian Logistics",
    industry: "Logistics",
    description: "A 12-module driver safety programme covering defensive driving, load security, fatigue management, and emergency procedures — delivered in 8 languages.",
    imageSrc: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=800",
    tags: ["Safety Videos", "Logistics", "Multilingual"],
    results: "35% reduction in driver incidents (Year 1)",
  },
  {
    slug: "hospitality-group-multilingual-onboarding",
    title: "Multilingual HR Onboarding for 3,500 Hospitality Workers",
    client: "Crescendo Hotels",
    industry: "Hospitality",
    description: "A full digital onboarding journey for new hospitality staff across 8 properties — covering brand standards, compliance training, and role-specific modules.",
    imageSrc: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800",
    tags: ["PULSYON", "HR Onboarding", "Hospitality"],
    results: "Time-to-productivity reduced by 30%",
  },
  {
    slug: "petrochemical-fire-safety-series",
    title: "Petrochemical Plant Fire Safety Video Series",
    client: "Confidential Client",
    industry: "Petrochemical",
    description: "A high-stakes fire safety and emergency response video series produced inside an active petrochemical facility — with full HSE protocols observed throughout.",
    imageSrc: "https://images.unsplash.com/photo-1613905780946-26b73b6f7e11?w=800",
    tags: ["Safety Videos", "Fire Safety", "Petrochemical"],
    results: "Used across 4 facilities, 6 languages",
  },
];

const industries = ["All", "Oil & Gas", "Construction", "Manufacturing", "Logistics", "Hospitality", "Petrochemical"];

export default function OurWorkPage() {
  const schema = webPageSchema({
    name: "Our Work — Case Studies",
    description: "Portfolio of safety video productions and PULSYON onboarding projects.",
    url: absoluteUrl("/our-work"),
    breadcrumbs: [
      { name: "Home", url: absoluteUrl("/") },
      { name: "Our Work", url: absoluteUrl("/our-work") },
    ],
  });

  return (
    <>
      <JsonLd data={schema} />

      <HeroBanner
        eyebrow="Our Work"
        title="Projects That Make a Difference"
        description="Real results for real enterprises. Browse our portfolio of safety video productions and PULSYON onboarding implementations."
        breadcrumbs={[{ label: "Our Work" }]}
      />

      {/* Filters + grid */}
      <section className="py-20 bg-[#FAFAF8]" aria-labelledby="portfolio-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="Portfolio"
            title="Case Studies & Projects"
            description="A selection from our growing portfolio of enterprise projects."
            className="mb-10"
          />

          {/* Industry filter */}
          <div className="flex flex-wrap gap-2 mb-10" role="group" aria-label="Filter by industry">
            {industries.map((ind) => (
              <button
                key={ind}
                aria-pressed={ind === "All"}
                className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
                  ind === "All"
                    ? "bg-[#E8521A] text-white border-[#E8521A]"
                    : "bg-white text-gray-600 border-gray-200 hover:border-[#E8521A] hover:text-[#E8521A]"
                }`}
              >
                {ind}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {caseStudies.map((cs) => (
              <CaseStudyCard key={cs.slug} caseStudy={cs} />
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-white border-y border-gray-100" aria-label="Portfolio statistics">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {[
              { value: "200+", label: "Videos Produced" },
              { value: "50K+", label: "Workers Trained" },
              { value: "15+", label: "Industries Served" },
              { value: "40+", label: "Languages Supported" },
            ].map(({ value, label }) => (
              <div key={label}>
                <div className="text-4xl lg:text-5xl font-bold text-[#E8521A] mb-2">{value}</div>
                <div className="text-gray-500 text-sm">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTABanner
        eyebrow="Start Your Project"
        title="Ready to Create Something Exceptional?"
        description="Tell us about your project and we'll show you how People Pulse Media can deliver results."
        primaryCta={{ label: "Book a Meeting", href: "/contact#book" }}
        secondaryCta={{ label: "Book a PULSYON Demo", href: "/onboarding-assessment#demo" }}
      />
    </>
  );
}
