import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import JsonLd from "@/components/seo/JsonLd";
import { organizationSchema, websiteSchema } from "@/lib/schema";

export const metadata: Metadata = {
  title: {
    template: "%s | People Pulse Media",
    default: "People Pulse Media — Safety Videos & PULSYON Onboarding Platform",
  },
  description:
    "People Pulse Media produces premium safety videos and PULSYON — the multilingual onboarding & assessment platform for enterprise workforces in 40+ languages.",
  keywords:
    "safety videos, onboarding platform, multilingual training, PULSYON, workplace safety, HSE training, employee onboarding",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://peoplepulsemedia.com"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://peoplepulsemedia.com",
    siteName: "People Pulse Media",
  },
  twitter: {
    card: "summary_large_image",
    creator: "@PeoplePulseMedia",
    site: "@PeoplePulseMedia",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <JsonLd data={[organizationSchema(), websiteSchema()]} />
      </head>
      <body className="bg-[#FAFAF8] text-[#0A0A0A]">
        <Header />
        <main id="main-content">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
